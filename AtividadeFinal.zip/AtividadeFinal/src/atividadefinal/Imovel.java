/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atividadefinal;


public class Imovel {

    private String nome;
    private String des;
    private String cat;
    private String tipo;
    private String valor;
    
    public Imovel(){
    
    }

    public Imovel(String nome, String des, String cat, String tipo, String valor) {
        this.nome = nome;
        this.des = des;
        this.cat = cat;
        this.tipo = tipo;
        this.valor = valor;
    }
    
    
    
    public String getNome() {
        return nome;
    }

    
    public void setNome(String nome) {
        this.nome = nome;
    }

    
    public String getDes() {
        return des;
    }

    
    public void setDes(String des) {
        this.des = des;
    }

    
    public String getCat() {
        return cat;
    }

    
    public void setCat(String cat) {
        this.cat = cat;
    }

    
    public String getTipo() {
        return tipo;
    }

  
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    
    public String getValor() {
        return valor;
    }

    
    public void setValor(String valor) {
        this.valor = valor;
    }
    
}

